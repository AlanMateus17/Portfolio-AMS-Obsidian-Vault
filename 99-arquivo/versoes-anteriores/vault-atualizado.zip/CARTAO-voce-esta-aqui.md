---
tags: [hoje, portfolio-ams]
tipo: dashboard-diario
---

# 📍 Você Está Aqui

> **Primeira vez ou perdido?** Leia o [Guia do Iniciante](00-GUIA-DO-INICIANTE.md): o plano inteiro, em ordem e em palavras simples. Palavras difíceis: [Glossário](00-GLOSSARIO.md).
> **O que fazer agora, item por item:** [📋 Plano Mestre passo a passo](00-PLANO-MESTRE-PASSO-A-PASSO.md) — **todos os passos dos dois planejamentos (setup + estudo) num só lugar, com códigos**.

*[← Voltar pro Início](00-INICIO.md)*

**Fase atual:** Passo 1 — Fundamentos (Lógica de Programação + Matemática Básica)
**Sistema em construção:** nenhum ainda — isso é o alicerce antes do primeiro código do AM Kaixara

---

## ✅ Faça isso hoje, e só isso

1. Abra **[EPIC-01-backlog-passo1-fundamentos](07-estudo-e-carreira/EPIC-01-backlog-passo1-fundamentos.md)**
2. Vá em **Sprint 1 → US-01** (ou a próxima User Story não marcada)
3. Faça as Tasks daquela User Story
4. Marque o que terminou
5. Feche o arquivo. Pare por hoje.

Não precisa abrir mais nenhum outro documento.

---

## 🚫 Não pense nisso agora — está guardado, não perdido

- Os outros 20 sistemas do portfólio
- Qualquer serviço `aura-*` (identity, vault, licensing, etc.)
- Segurança avançada, pentest, IA
- Qualquer tecnologia além de lógica pura e o livro de matemática
- "Como vou dar conta de tudo isso" — você não precisa dar conta de tudo isso hoje, só de uma User Story

---

## 🔜 Quando terminar o EPIC-01 inteiro

Abra **[00-SUMARIO-UNICO-SEQUENCIA-DE-ESTUDO](00-SUMARIO-UNICO-SEQUENCIA-DE-ESTUDO.md)** → marque o Passo 1 como concluído → siga pro **Passo 2**. Ele te diz exatamente o próximo bloco, na mesma lógica de hoje.

---

## 🧭 Se perder o fio de novo

Releia só este cartão. Não abra os outros 40 arquivos pra "se situar" — eles não vão te situar, vão te afogar de novo. Este cartão é a situação.
